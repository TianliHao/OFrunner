var a02549 =
[
    [ "typed_size", "a02549.html#a38db48768cee533212856ab7f12e5b86", null ],
    [ "value_type", "a02549.html#ab0520cc6fad9d4a109da0a174b2f07c5", null ],
    [ "vector_type", "a02549.html#a9361e3220c79fab2d2deadb8f320acf1", null ]
];