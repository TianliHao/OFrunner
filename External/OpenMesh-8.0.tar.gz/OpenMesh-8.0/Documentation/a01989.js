var a01989 =
[
    [ "_OBJReader_", "a01989.html#a53b08a9aff4d7a486cba66584ab04d1a", null ],
    [ "~_OBJReader_", "a01989.html#a70ee2a1eaeb8d49aee5ad9f4d6b6c1da", null ],
    [ "get_description", "a01989.html#af7f27509f9ac2bd59dd0f31535b43ccb", null ],
    [ "get_extensions", "a01989.html#a8619b817593f5e88ddbded9cc94cea41", null ],
    [ "read", "a01989.html#a63954abd80bd199f5e6bd76e2346cd34", null ],
    [ "read", "a01989.html#a3aa2dc8668159e54b09cc573a89b49be", null ]
];