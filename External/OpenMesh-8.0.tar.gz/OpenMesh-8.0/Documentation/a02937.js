var a02937 =
[
    [ "Normal", "a02937.html#aea55622af191245b83b5d7cdc1932a76", null ],
    [ "Point", "a02937.html#a633e5ca0ed5b82d4f2aa6700ae29ebd9", null ],
    [ "TexCoord2D", "a02937.html#afb043e922e6c3cd56a35e54ba61571c2", null ],
    [ "TexCoord3D", "a02937.html#ae8d2ffc3247b2cee67a3fa7f4c5c7a73", null ]
];