var a02857 =
[
    [ "Gnuplot", "a02857.html#a936d27de7b6f57d1f3d61491dc70f1ae", null ],
    [ "Gnuplot", "a02857.html#ae0395678b8c18a041941b180478c3a55", null ],
    [ "Gnuplot", "a02857.html#a06060d149c16680317bc479d8defc2e5", null ],
    [ "Gnuplot", "a02857.html#a69e932f3df2490f3c5c7e63892b7633e", null ],
    [ "~Gnuplot", "a02857.html#a78a68f621caa87d1f34324fcd093c7bd", null ],
    [ "cmd", "a02857.html#a6253320f82f18a7a681ccecaac0898b6", null ],
    [ "is_active", "a02857.html#ae8a8d7046bef986dd36922bdfb8ae179", null ],
    [ "is_valid", "a02857.html#a24abcb95740bffac41022227187748e4", null ],
    [ "plot_equation", "a02857.html#afb72ee2b5e6d7d777f1953ebf110947a", null ],
    [ "plot_slope", "a02857.html#a538309f9db7cb199030d5d75912f9ab8", null ],
    [ "plot_x", "a02857.html#ab8e2cc098981edc58c82389b53ac3a0a", null ],
    [ "plot_xy", "a02857.html#a5442faded1dc684e3fc1d3a43e0953a2", null ],
    [ "reset_plot", "a02857.html#ad54976652afe30231a850dd31e1ca70f", null ],
    [ "set_style", "a02857.html#ad578ceaa5175865aeb7ffece4602c0ab", null ],
    [ "set_xlabel", "a02857.html#a27cbe28fc00b26c917ac624835b04dae", null ],
    [ "set_ylabel", "a02857.html#afbda5bf606089a736528f4e15a897043", null ]
];