var a02197 =
[
    [ "HalfedgeHandle", "a02197.html#a624b9ea822181c89bf9e685283659161", null ]
];