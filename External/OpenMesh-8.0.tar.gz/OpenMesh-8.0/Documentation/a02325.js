var a02325 =
[
    [ "Type", "a02325.html#a9ccf92afc560bd415eeeda60b4870042", [
      [ "LSB", "a02325.html#a9ccf92afc560bd415eeeda60b4870042a6122652d3bc6c9f6c10cf9518a5f4e24", null ],
      [ "MSB", "a02325.html#a9ccf92afc560bd415eeeda60b4870042ac1f56fc0f17f4491229e17218ab557c0", null ]
    ] ]
];