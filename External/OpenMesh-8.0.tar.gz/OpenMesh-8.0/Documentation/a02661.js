var a02661 =
[
    [ "EdgeT", "a02673.html", "a02673" ],
    [ "FaceT", "a02669.html", "a02669" ],
    [ "State", "a02665.html", "a02665" ],
    [ "VertexT", "a02677.html", "a02677" ],
    [ "final_t", "a02661.html#a6130640284ae3223c2a7e3c54269d4f1", null ],
    [ "state_t", "a02661.html#a13c642f3a0e8bfb626e99d0d27b7fdd9", null ],
    [ "FaceAttributes", "a02661.html#a3f66494113d1cab98d16193096274e38a0df83e391d1ec7a31f379421620ce1dd", null ],
    [ "VertexAttributes", "a02661.html#a1202bd17bc21d4b75513f523cedcf3d5a22e7462f43622ff48a71f4839ddfc1da", null ],
    [ "HalfedgeAttributes", "a02661.html#a601f80dd60b5a259210abf8bbf09759da0fc7210a7fffcd5b03b89a647e3ddf20", null ]
];