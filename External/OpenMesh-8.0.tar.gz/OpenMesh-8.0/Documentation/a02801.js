var a02801 =
[
    [ "FVCoeff", "a02805.html", "a02805" ],
    [ "Coeff", "a02801.html#a51f676308b796d2388577fb9462bc76e", null ],
    [ "Inherited", "a02801.html#a009d16d1903d3455e7872901e2c927f7", null ],
    [ "CompositeSqrt3T", "a02801.html#ac44f9b9e3f7f163e7de5869f54d9ab4b", null ],
    [ "CompositeSqrt3T", "a02801.html#acde2583b232d49fb6b79d92cbed13660", null ],
    [ "~CompositeSqrt3T", "a02801.html#ad57715ac9bb42648964d80ee58cffcbb", null ],
    [ "apply_rules", "a02801.html#a002726eaa6860072f116de68e90b64a7", null ],
    [ "name", "a02801.html#a8bac4e5fe67aca52b8c8837b6d8364ba", null ],
    [ "coeffs_", "a02801.html#a2f3b940fc080a39727acd56f1b8e50fc", null ]
];