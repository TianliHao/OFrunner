var a01833 =
[
    [ "Refs", "a01833.html#af0ee51596f4578845a761f1e8163af06", null ],
    [ "halfedges", "a01833.html#afd56cdde651aaef4a8d476da52a7ee68", null ]
];