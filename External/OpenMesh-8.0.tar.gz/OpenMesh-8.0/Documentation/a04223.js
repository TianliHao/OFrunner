var a04223 =
[
    [ "DefaultTraits", "a02297.html", "a02297" ],
    [ "MergeTraits", "a02301.html", null ],
    [ "EdgeAttributes", "a04223.html#a8126b6d66b0b65c5e23e8856c6092c28", null ],
    [ "EdgeTraits", "a04223.html#adbd10edc9787f8347769a11391896d9e", null ],
    [ "FaceAttributes", "a04223.html#a75f0d731abf2489208086aac5147eefc", null ],
    [ "FaceTraits", "a04223.html#a48a58bb27b065ea6b5f6e973756f1800", null ],
    [ "HalfedgeAttributes", "a04223.html#a72688ff15a275a41a98159ce72eaab4f", null ],
    [ "HalfedgeTraits", "a04223.html#a223434df0f07f8e05b89324094fc1de8", null ],
    [ "OM_Merge_Traits", "a04223.html#a746c83f2828928d4e7c4de0b2613e396", null ],
    [ "OM_Merge_Traits_In_Template", "a04223.html#a97a9676df79fe2881136f983f3cf3b05", null ],
    [ "VertexAttributes", "a04223.html#a427ff443d5e47c76b9c45a29213e63db", null ],
    [ "VertexTraits", "a04223.html#aa5146d858418fcb93715406a6ce8e30f", null ]
];