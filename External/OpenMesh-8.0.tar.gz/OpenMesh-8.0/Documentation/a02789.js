var a02789 =
[
    [ "EVCoeff", "a02793.html", "a02793" ],
    [ "Coeff", "a02789.html#a320f56b1af47a737d99244aa8fb70a97", null ],
    [ "Inherited", "a02789.html#aba7df5504247de7b66d792bb8e737eb9", null ],
    [ "CompositeLoopT", "a02789.html#a19cc806819ab937cb3a7e341838b389a", null ],
    [ "CompositeLoopT", "a02789.html#a7c8e16d1f259fa7b2918f3b827de33b1", null ],
    [ "~CompositeLoopT", "a02789.html#a2f96b9c290c455fb1c0b13e59a91d0ed", null ],
    [ "apply_rules", "a02789.html#a91afe60dc791d39f82547a151015de46", null ],
    [ "name", "a02789.html#aeddd79a8b5222acd45868efc9650003b", null ],
    [ "coeffs_", "a02789.html#a3fb84da805914b8d6e4a20cb49ccf4e3", null ]
];