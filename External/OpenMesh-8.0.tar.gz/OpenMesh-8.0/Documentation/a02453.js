var a02453 =
[
    [ "CollapseInfo", "a02453.html#a8cc9f0b0682dbead98929e929e18d2cf", null ],
    [ "Mesh", "a02453.html#a859ae4de39db6d7e9d1a1ad1335fb897", null ],
    [ "ILLEGAL_COLLAPSE", "a02453.html#a49500127c96591367298aa17e8527e44afc88837943f46ccbf0ef35d3fcf9c5b1", null ],
    [ "LEGAL_COLLAPSE", "a02453.html#a49500127c96591367298aa17e8527e44a2b521064f4abfdfb6eb5464308b6f6e7", null ],
    [ "ModBaseT", "a02453.html#ac434e4c53a1502b51c9bf8f79214727e", null ],
    [ "~ModBaseT", "a02453.html#ab2e5893b8418b3bbf4c88fc5cb7b75e5", null ],
    [ "collapse_priority", "a02453.html#acb81c6b9a752741fce2366ca605cd14c", null ],
    [ "initialize", "a02453.html#a2c6972aeffef98839951846051690c0b", null ],
    [ "is_binary", "a02453.html#a1c102bc43acb81911c27024032b48b02", null ],
    [ "mesh", "a02453.html#a4b4ef38dac53440f7a01402a6844722a", null ],
    [ "name", "a02453.html#add0059ed0204bb8ec2fce853d509d1aa", null ],
    [ "postprocess_collapse", "a02453.html#a9b79ddfa2e7771572dd558c928edcdeb", null ],
    [ "preprocess_collapse", "a02453.html#a4d6aa846add0068b1e2bd7005e60edb4", null ],
    [ "set_binary", "a02453.html#a36fbc3ecb0b707e2087aea565c5bd6b5", null ],
    [ "set_error_tolerance_factor", "a02453.html#a3f1b2156b44cff425dd758e84218f0db", null ],
    [ "error_tolerance_factor_", "a02453.html#a3893f0f6368f1a1fe5e37f6006d72d62", null ]
];