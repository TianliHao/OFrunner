var a01993 =
[
    [ "_OFFReader_", "a01993.html#a476dd81d1647bbe537892c362c9ac6ca", null ],
    [ "~_OFFReader_", "a01993.html#a03ed5cb451f35941a024c3933a3abd0b", null ],
    [ "can_u_read", "a01993.html#abbe833299f79b23de4bf4c1bf1580713", null ],
    [ "get_description", "a01993.html#af0b9c6ad19b00a2c72ce5e87ec399755", null ],
    [ "get_extensions", "a01993.html#a36bf8b125fad9000bf91c99267e09420", null ],
    [ "get_magic", "a01993.html#aef5cc41f31dec673a0141f6a75a87c75", null ],
    [ "read", "a01993.html#ae6abbcd58b42708cdaf454a92a8e42c3", null ],
    [ "read", "a01993.html#aa94f52dc263700daa126a32ec1018e2f", null ]
];