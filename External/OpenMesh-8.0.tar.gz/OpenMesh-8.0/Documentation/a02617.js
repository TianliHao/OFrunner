var a02617 =
[
    [ "BaseType", "a02617.html#a8075f02b2644592ca85dea53a4f31be5", null ],
    [ "SmartTaggerVT", "a02617.html#a83296872f8f92d1e83287ace3a32daf0", null ]
];