var a03209 =
[
    [ "MyData", "a03209.html#af6b8e9f33b1ca65a43c3e187089625d3", null ],
    [ "MyData", "a03209.html#a2498835c0e5cc2dffd0624761323d092", null ],
    [ "operator!=", "a03209.html#aff044fad344dd1b1181ff14b61ef822d", null ],
    [ "operator=", "a03209.html#a57b8a42348369ba717315dec331eeb94", null ],
    [ "operator=", "a03209.html#ad1501cc901067bf7361add8c39b8c7c4", null ],
    [ "operator=", "a03209.html#acbeea404456be838406c7ce4dc8dc749", null ],
    [ "operator=", "a03209.html#af000b1f7dc0d848ecddff16d40280cb9", null ],
    [ "operator=", "a03209.html#a407ac0251d256819a3653c32acc2a373", null ],
    [ "operator==", "a03209.html#a4654882e2258cf92e8065f61fa251c12", null ],
    [ "bval", "a03209.html#afcf33375954ae194227aeb7c733de983", null ],
    [ "dval", "a03209.html#ad974b667c0e6a50fdf4f9f12dad940b9", null ],
    [ "ival", "a03209.html#a06767e9b1ab7f029da96cdc22bf7ca98", null ],
    [ "vec4fval", "a03209.html#a6253adfccb8274a8a8fe438628e98d2a", null ]
];