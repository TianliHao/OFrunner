var a02833 =
[
    [ "mesh_t", "a02833.html#a4c2bd18d13af40e004814e66e2e83f21", null ],
    [ "parent_t", "a02833.html#a32cac0953e9ccfdab3825e8fa9710b8b", null ],
    [ "real_t", "a02833.html#ae853054b768347ead3c3a239cbd99bc5", null ],
    [ "weight_t", "a02833.html#a42b598e7c4f594fa60eae79b75896ddd", null ],
    [ "weights_t", "a02833.html#a58bfb9902c057b9691dc3329391b2cc2", null ],
    [ "ModifiedButterflyT", "a02833.html#a18defcc08980d311fe53fbb57b1c63ee", null ],
    [ "ModifiedButterflyT", "a02833.html#a76aa04dd324557bad4acf1f8610cb142", null ],
    [ "~ModifiedButterflyT", "a02833.html#a95fbb2406cbeb58f30780a92af32760a", null ],
    [ "cleanup", "a02833.html#ab4ad979e5bdaf16dab2f84063071857d", null ],
    [ "init_weights", "a02833.html#a81b2612d667f5e1e4baa6678f6981b0d", null ],
    [ "name", "a02833.html#a2c530bdd0adca70f5d61fc2cc379aea7", null ],
    [ "prepare", "a02833.html#a5cb2f2cf637a0c07a7fab9a2fcedeb5c", null ],
    [ "subdivide", "a02833.html#a8268bf3fb5ddd8a05fc1f3d128bee933", null ]
];