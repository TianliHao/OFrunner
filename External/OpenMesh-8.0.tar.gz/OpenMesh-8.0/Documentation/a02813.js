var a02813 =
[
    [ "queueElement", "a02813.html#a73bc58b896e706fe0844d45a6a776449", null ],
    [ "operator()", "a02813.html#a17bf78ee09ab473f61bbec7d6ac4abd5", null ]
];