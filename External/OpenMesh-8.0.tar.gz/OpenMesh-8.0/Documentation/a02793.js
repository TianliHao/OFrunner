var a02793 =
[
    [ "compute_weight", "a02797.html", "a02797" ],
    [ "EVCoeff", "a02793.html#afb7c41edac2135d901a7bb1eafafffeb", null ],
    [ "init", "a02793.html#a20e9c92a4b77e9033a45b2bd1432bb19", null ],
    [ "operator()", "a02793.html#aa38aef45738f8599d1afb8e89e5e4edb", null ],
    [ "weights_", "a02793.html#ab019f704f4bea47348a71569c316ac29", null ]
];