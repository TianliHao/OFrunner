var dir_80f26c7d87f9f73a44fbb7bc7b8fb5a6 =
[
    [ "BaseDecimaterT.hh", "a00521.html", [
      [ "BaseDecimaterModule", "a02417.html", null ],
      [ "BaseDecimaterT", "a02421.html", "a02421" ]
    ] ],
    [ "BaseDecimaterT_impl.hh", "a00524_source.html", null ],
    [ "CollapseInfoT.hh", "a00527.html", [
      [ "CollapseInfoT", "a02425.html", "a02425" ]
    ] ],
    [ "DecimaterT.hh", "a00530.html", [
      [ "DecimaterT", "a02429.html", "a02429" ],
      [ "HeapInterface", "a02433.html", "a02433" ]
    ] ],
    [ "DecimaterT_impl.hh", "a00533.html", "a00533" ],
    [ "McDecimaterT.hh", "a00536.html", [
      [ "McDecimaterT", "a02437.html", "a02437" ]
    ] ],
    [ "McDecimaterT_impl.hh", "a00539.html", "a00539" ],
    [ "MixedDecimaterT.hh", "a00542.html", [
      [ "MixedDecimaterT", "a02441.html", "a02441" ]
    ] ],
    [ "MixedDecimaterT_impl.hh", "a00545.html", "a00545" ],
    [ "ModAspectRatioT.hh", "a00548.html", [
      [ "ModAspectRatioT", "a02445.html", "a02445" ]
    ] ],
    [ "ModAspectRatioT_impl.hh", "a00551.html", "a00551" ],
    [ "ModBaseT.hh", "a00554.html", "a00554" ],
    [ "ModEdgeLengthT.hh", "a00557.html", [
      [ "ModEdgeLengthT", "a02457.html", "a02457" ]
    ] ],
    [ "ModEdgeLengthT_impl.hh", "a00560.html", "a00560" ],
    [ "ModHausdorffT.hh", "a00563.html", [
      [ "ModHausdorffT", "a02461.html", "a02461" ]
    ] ],
    [ "ModHausdorffT_impl.hh", "a00566.html", "a00566" ],
    [ "ModIndependentSetsT.hh", "a00569_source.html", null ],
    [ "ModNormalDeviationT.hh", "a00572.html", [
      [ "ModNormalDeviationT", "a02469.html", "a02469" ]
    ] ],
    [ "ModNormalFlippingT.hh", "a00575.html", [
      [ "ModNormalFlippingT", "a02473.html", "a02473" ]
    ] ],
    [ "ModProgMeshT.hh", "a00578.html", [
      [ "ModProgMeshT", "a02477.html", "a02477" ],
      [ "Info", "a02481.html", "a02481" ]
    ] ],
    [ "ModProgMeshT_impl.hh", "a00581.html", "a00581" ],
    [ "ModQuadricT.hh", "a00584.html", [
      [ "ModQuadricT", "a02485.html", "a02485" ]
    ] ],
    [ "ModQuadricT_impl.hh", "a00587.html", "a00587" ],
    [ "ModRoundnessT.hh", "a00590.html", [
      [ "ModRoundnessT", "a02489.html", "a02489" ]
    ] ],
    [ "Observer.cc", "a00593.html", null ],
    [ "Observer.hh", "a00596.html", [
      [ "Observer", "a02493.html", "a02493" ]
    ] ]
];