var a02345 =
[
    [ "type", "a02345.html#a8502c84d90dfd772ff477ba7fcc2e2da", null ]
];