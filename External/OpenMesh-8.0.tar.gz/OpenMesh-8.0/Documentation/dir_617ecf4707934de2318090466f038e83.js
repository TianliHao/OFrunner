var dir_617ecf4707934de2318090466f038e83 =
[
    [ "Composite", "dir_3cde2ca7af9740c5b0d23b8cc04dfa69.html", "dir_3cde2ca7af9740c5b0d23b8cc04dfa69" ],
    [ "CatmullClarkT.hh", "a00665.html", [
      [ "CatmullClarkT", "a02761.html", "a02761" ]
    ] ],
    [ "CatmullClarkT_impl.hh", "a00668_source.html", null ],
    [ "CompositeLoopT.hh", "a00671.html", [
      [ "CompositeLoopT", "a02789.html", "a02789" ],
      [ "EVCoeff", "a02793.html", "a02793" ],
      [ "compute_weight", "a02797.html", "a02797" ]
    ] ],
    [ "CompositeSqrt3T.hh", "a00674.html", [
      [ "CompositeSqrt3T", "a02801.html", "a02801" ],
      [ "FVCoeff", "a02805.html", "a02805" ],
      [ "compute_weight", "a02809.html", "a02809" ]
    ] ],
    [ "LongestEdgeT.hh", "a00677.html", [
      [ "CompareLengthFunction", "a02813.html", "a02813" ],
      [ "LongestEdgeT", "a02817.html", "a02817" ]
    ] ],
    [ "LoopT.hh", "a00680.html", "a00680" ],
    [ "MidpointT.hh", "a00683_source.html", null ],
    [ "ModifiedButterFlyT.hh", "a00686.html", [
      [ "ModifiedButterflyT", "a02833.html", "a02833" ]
    ] ],
    [ "Sqrt3InterpolatingSubdividerLabsikGreinerT.hh", "a00689.html", "a00689" ],
    [ "Sqrt3T.hh", "a00692.html", "a00692" ],
    [ "SubdividerT.hh", "a00695.html", "a00695" ]
];