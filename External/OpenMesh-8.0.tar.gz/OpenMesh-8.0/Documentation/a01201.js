var a01201 =
[
    [ "KernelT", "a01841.html", "a01841" ],
    [ "MeshItems", "a01821.html", [
      [ "EdgeT", "a01833.html", "a01833" ],
      [ "FaceT", "a01837.html", "a01837" ],
      [ "HalfedgeT", "a01829.html", "a01829" ],
      [ "VertexT", "a01825.html", "a01825" ]
    ] ]
];