var a02045 =
[
    [ "_OMWriter_", "a02045.html#a124124ec1cf547f34f7f07c3c5345267", null ],
    [ "~_OMWriter_", "a02045.html#ae824f4266ba7a3230c483f10c90b2c22", null ],
    [ "binary_size", "a02045.html#ad41895c4a359a9829de5c5414c06c5d1", null ],
    [ "get_description", "a02045.html#a8db717904900634a827fe1331c0b962a", null ],
    [ "get_extensions", "a02045.html#a20e00c174bfdad416c7ba580ea407bc5", null ],
    [ "store_binary_custom_chunk", "a02045.html#afb4da2e614e0b1ee2d177b4fcdc9b92f", null ],
    [ "write", "a02045.html#a3efe93376254bb15124c3c14922e5d64", null ],
    [ "write", "a02045.html#a096575651a73596687e6b35132474b29", null ],
    [ "write_binary", "a02045.html#a3af94cce280d8d2f5c29fcdfaaf07bec", null ]
];