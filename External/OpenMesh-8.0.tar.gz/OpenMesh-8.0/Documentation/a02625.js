var a02625 =
[
    [ "BaseType", "a02625.html#a82070b85179fea91a305c152d91b4f64", null ],
    [ "SmartTaggerFT", "a02625.html#a313861a77ef93b8130eb5f9b293a81c7", null ]
];