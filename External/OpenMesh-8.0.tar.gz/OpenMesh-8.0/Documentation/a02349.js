var a02349 =
[
    [ "type", "a02349.html#a62fdfc2a07706e4ffd8f7c379ff3f79f", null ]
];