var a02645 =
[
    [ "EdgeHandle", "a02645.html#a13bc5af7cbfbd9aceffe641ee7e39428", null ],
    [ "NormalType", "a02645.html#a133102bd0c12a8130285d79e7e7ecc3e", null ],
    [ "Point", "a02645.html#aadfb4510075ee3ffff7f19ef62cf88a8", null ],
    [ "Scalar", "a02645.html#a821709705d2f795e4226eac61f35200b", null ],
    [ "VertexHandle", "a02645.html#a3d89accc059b42abcafd7d888f9b6d97", null ],
    [ "Component", "a02645.html#a867faa77ce2ddee85543459f6653af18", [
      [ "Tangential", "a02645.html#a867faa77ce2ddee85543459f6653af18abe52e6b9d369495ca31057e39e29e465", null ],
      [ "Normal", "a02645.html#a867faa77ce2ddee85543459f6653af18af2527cfb0045e95d97010a5621e9ca5c", null ],
      [ "Tangential_and_Normal", "a02645.html#a867faa77ce2ddee85543459f6653af18a898a6c92513c4d4ec9fbd4652752c602", null ]
    ] ],
    [ "Continuity", "a02645.html#aafd6f051464295a9900846ed431f3610", [
      [ "C0", "a02645.html#aafd6f051464295a9900846ed431f3610a3d371b8e298b792d80b6004f84c1b8b1", null ],
      [ "C1", "a02645.html#aafd6f051464295a9900846ed431f3610ac3ca183e3c39091e3b033527b32acdcf", null ],
      [ "C2", "a02645.html#aafd6f051464295a9900846ed431f3610a6933a74d441609c5d5fbe6a7a35ffa3d", null ]
    ] ],
    [ "SmootherT", "a02645.html#af300a00749e27e052aac01f998532587", null ],
    [ "~SmootherT", "a02645.html#aed79f05f0eadb16108a9297f1d70ad6a", null ],
    [ "component", "a02645.html#a57aedf5150c31473624425b92ca19b2f", null ],
    [ "compute_new_positions_C0", "a02645.html#abe7a849f0c90a8675d7bfe8ad24d4970", null ],
    [ "compute_new_positions_C1", "a02645.html#aed9c534d5b6df5d02e8d487163ab7a1d", null ],
    [ "continuity", "a02645.html#a6474ffefd27d18ffa6014fd635107867", null ],
    [ "disable_local_error_check", "a02645.html#aac72d74a6daf8c8fb24a0437f022dabb", null ],
    [ "initialize", "a02645.html#a8f76bf70d991095b63f4161cc8406b6a", null ],
    [ "is_active", "a02645.html#a505ea3528f25ef9299ea992934fb4a97", null ],
    [ "new_position", "a02645.html#aed59607a4db2bc26f880906ce5bc8864", null ],
    [ "orig_normal", "a02645.html#a9f02ed5fcbbab08e4739540cdcd6d4bd", null ],
    [ "orig_position", "a02645.html#aa28a47f0f0a42f4aff391336e2195421", null ],
    [ "set_absolute_local_error", "a02645.html#aa4afc9ae6b9ce5f3fc1ea7372ce0b42f", null ],
    [ "set_new_position", "a02645.html#a1173442f5f5a83084d4c3fb72d1ce2a0", null ],
    [ "set_relative_local_error", "a02645.html#acd0b96d45f71d37584cd91e067397e7b", null ],
    [ "skip_features", "a02645.html#affa58655ba9762e346d71f77b656c19d", null ],
    [ "smooth", "a02645.html#a6f87efbec4758b930d02372f26c8bed8", null ],
    [ "mesh_", "a02645.html#a0d0fe0cb163f0da862c772818a5ee326", null ],
    [ "skip_features_", "a02645.html#a78a7d0b7b1afd9b19f1dbd0011aab99a", null ]
];