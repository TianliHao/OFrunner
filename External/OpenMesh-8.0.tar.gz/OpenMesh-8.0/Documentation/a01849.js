var a01849 =
[
    [ "VertexT", "a01849.html#a724246add78300a73b06b096869d46e1", null ],
    [ "VertexT", "a01849.html#a724246add78300a73b06b096869d46e1", null ],
    [ "cog", "a01849.html#a4a12ec3ec08b3b19378c48960376400c", null ],
    [ "cog", "a01849.html#a4a12ec3ec08b3b19378c48960376400c", null ],
    [ "set_cog", "a01849.html#a188be293a85465cae0c87d084cdcf1f8", null ],
    [ "set_cog", "a01849.html#a188be293a85465cae0c87d084cdcf1f8", null ]
];