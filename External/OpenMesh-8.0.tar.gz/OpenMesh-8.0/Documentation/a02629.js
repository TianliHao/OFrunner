var a02629 =
[
    [ "BaseType", "a02629.html#a457a9febf5276037192e1f838a0fcffa", null ],
    [ "SmartTaggerHT", "a02629.html#a9d3d74b78d00a75a1431445867d62e06", null ]
];