var a01845 =
[
    [ "VertexT", "a01849.html", "a01849" ],
    [ "Normal", "a01845.html#a85f818c1f4db2d21070fa2a319a0bdae", null ],
    [ "Point", "a01845.html#ae284e0bf977881329835f14fae5a7fa8", null ],
    [ "VertexAttributes", "a01845.html#a73a2769d3cebc39a352f07796938bfeea3240d04f10c701518864bee168853a62", null ],
    [ "FaceAttributes", "a01845.html#ad50d7e0bb259f4ccfb04df56801974bdad44da413bf3420d9c5fee92c014ef4b1", null ],
    [ "VertexAttributes", "a01845.html#a73a2769d3cebc39a352f07796938bfeea3240d04f10c701518864bee168853a62", null ],
    [ "VertexAttributes", "a01845.html#a73a2769d3cebc39a352f07796938bfeea3240d04f10c701518864bee168853a62", null ],
    [ "FaceAttributes", "a01845.html#ad50d7e0bb259f4ccfb04df56801974bdad44da413bf3420d9c5fee92c014ef4b1", null ],
    [ "EdgeAttributes", "a01845.html#a1f38b3545ff43d1592125a3afac4a172ad1b0d16e2b2ac31654bdd7c1d586a500", null ],
    [ "HalfedgeAttributes", "a01845.html#a67cd17c784659e33545c40c75b44688eaeaeb37b5a6657b4044c17183ac5e3937", null ],
    [ "FaceAttributes", "a01845.html#ad50d7e0bb259f4ccfb04df56801974bdad44da413bf3420d9c5fee92c014ef4b1", null ],
    [ "VertexAttributes", "a01845.html#a73a2769d3cebc39a352f07796938bfeea3240d04f10c701518864bee168853a62", null ],
    [ "EdgeAttributes", "a01845.html#a1f38b3545ff43d1592125a3afac4a172ad1b0d16e2b2ac31654bdd7c1d586a500", null ],
    [ "HalfedgeAttributes", "a01845.html#a67cd17c784659e33545c40c75b44688eaeaeb37b5a6657b4044c17183ac5e3937", null ],
    [ "FaceAttributes", "a01845.html#ad50d7e0bb259f4ccfb04df56801974bdad44da413bf3420d9c5fee92c014ef4b1", null ],
    [ "HalfedgeAttributes", "a01845.html#a67cd17c784659e33545c40c75b44688eaeaeb37b5a6657b4044c17183ac5e3937", null ]
];