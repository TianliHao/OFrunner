var a02457 =
[
    [ "Base", "a02457.html#a204d0fcac0fd209b1c7dc80546d7c074", null ],
    [ "CollapseInfo", "a02457.html#a97a335d3e836fed91982017de0354bdb", null ],
    [ "Handle", "a02457.html#a743c66317c69025676bae958245e77b2", null ],
    [ "Mesh", "a02457.html#a71e8766d0f5b1ae85743f6422f349e6d", null ],
    [ "Self", "a02457.html#a840742d97a803f25115d9efa289d049f", null ],
    [ "ModEdgeLengthT", "a02457.html#a64dacb1c6889dc21b25b8df488fc6cf6", null ],
    [ "collapse_priority", "a02457.html#a8b205feac99470a63e6c3351088513a0", null ],
    [ "edge_length", "a02457.html#ab5e760cd28b8523f64f0485674f700c4", null ],
    [ "name", "a02457.html#ae7e13c3309944d55337e0db8b12af47a", null ],
    [ "set_edge_length", "a02457.html#a50769dacd1da04bca568e2d441589a15", null ],
    [ "set_error_tolerance_factor", "a02457.html#a50454bc8ea7dd04451def96d6e447654", null ]
];