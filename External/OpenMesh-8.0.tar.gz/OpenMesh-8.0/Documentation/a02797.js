var a02797 =
[
    [ "compute_weight", "a02797.html#adf2bc905f8bc955c00a9b362b0f70f93", null ],
    [ "operator()", "a02797.html#add6b2b92d8b8ba0d8fe9335b4ceb1963", null ],
    [ "val_", "a02797.html#a5d608197835420b4c221b731673d3e3e", null ]
];