var a01825 =
[
    [ "Refs", "a01825.html#a1e5f6c61e62ce8fcf6e05ecfa22d76e8", null ],
    [ "VertexT", "a01825.html#ac714e165662433c27dbc482b7a524201", null ],
    [ "halfedge_handle", "a01825.html#ae6e7e6b43ecc58863612c896aa84c8e6", null ],
    [ "set_halfedge_handle", "a01825.html#a2e37f87e0ff740f42d6e700ccc5b71b1", null ]
];