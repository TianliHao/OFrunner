var a02485 =
[
    [ "Base", "a02485.html#addd357088ae34e7e066e7cc1e8c5b4a0", null ],
    [ "CollapseInfo", "a02485.html#a1a4e4575c2bb705e263d9dca5b9ed76f", null ],
    [ "Handle", "a02485.html#a6591c48feee7fe0d93af43e3ba8be72a", null ],
    [ "Mesh", "a02485.html#a52ade055c69629278d97a7cb7883d5c9", null ],
    [ "Self", "a02485.html#ad1653651c626cfa23f579193da6f1477", null ],
    [ "ModQuadricT", "a02485.html#a133497b5da2d4164a2caaa694af2c64a", null ],
    [ "~ModQuadricT", "a02485.html#ab61e337c3cea0e7c1e796207ec8bd7e0", null ],
    [ "collapse_priority", "a02485.html#af831bbc194faf3a3c346bd215f01f413", null ],
    [ "initialize", "a02485.html#aeeff135f4141c2f231f1428a974d7c0d", null ],
    [ "max_err", "a02485.html#adc91dc465e147abb93d23dec75920156", null ],
    [ "name", "a02485.html#adfd239a2bb4fa0c9d450b5b7df5f57f4", null ],
    [ "postprocess_collapse", "a02485.html#acc01feeb26061855e79480a035068c0c", null ],
    [ "set_error_tolerance_factor", "a02485.html#a31113d67dcd8953edef8377572e0b173", null ],
    [ "set_max_err", "a02485.html#a7fb01ec4e21be8b62d5c299b7126ce99", null ],
    [ "unset_max_err", "a02485.html#af4f40b99ab088afe24cf10e9b3cda469", null ]
];